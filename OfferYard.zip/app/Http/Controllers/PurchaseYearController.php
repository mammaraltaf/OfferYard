<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PurchaseYearController extends Controller
{
    //
}
