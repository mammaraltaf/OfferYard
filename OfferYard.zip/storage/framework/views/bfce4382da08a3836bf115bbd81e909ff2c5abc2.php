<div class="row m-0 mt-5 py-5 footer">
            <div class="container">
                <div class="row m-0">
                    <div class="col-md-3">
                        <h5><b>Popular Stores & Brands</b></h5>
                        <ul class="text-dark footer-list">
                            <li>Eastbay</li>
                            <li>Express</li>
                            <li>Foot Locker</li>
                            <li>Home Depot</li>
                            <li>Kohl's</li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h5><b>Categories</b></h5>
                        <ul class="text-dark footer-list">
                            <li>Women's Clothing</li>
                            <li>Computers</li>
                            <li>Electronics</li>
                            <li>Food & Gifts</li>
                            <li>Travel</li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h5><b>Holidays</b></h5>
                        <ul class="text-dark footer-list">
                            <li>Easter</li>
                            <li>AAPI-Owned Businesses</li>
                            <li>Graduation</li>
                            <li>Black Friday Deals</li>
                            <li>Cyber Monday 2022 Deals</li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h5><b>Savings Tips</b></h5>
                        <ul class="text-dark footer-list">
                            <li>Blog</li>
                            <li>Fast Food</li>
                            <li>Military Discounts</li>
                            <li>Student Discounts</li>
                            <li>Kohl's</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row m-0 py-2 bg-secondary">
            <div class="container">
                <div class="col-md-12 text-mute">© 2023 abc.com, LLC, a company. All Rights Reserved.</div>
            </div>
        </div><?php /**PATH D:\laragon\www\OfferYard\resources\views/components/footer.blade.php ENDPATH**/ ?>