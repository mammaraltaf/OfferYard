








































































<html>
<head>
    <title>Login | OfferYard</title>
    <?php echo $__env->make('cdn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="bg-light">
<div class="container" style="height:100vh;">
    <div class="row m-0 d-flex justify-content-center align-items-center" style="height:100vh;">
        <div class="col-md-6 bg-white shadow rounded p-5">
            <?php echo $__env->make('admin.partials.sessionMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <h4 class="text-center">LOGIN SYSTEM</h4>
            <form action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="text" class="form-control" placeholder="user@offeryard.com" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="pwd">Password:</label>
                    <input type="password" class="form-control" placeholder="Enter password" id="pwd" name="password">
                </div>
                <div class="form-group form-check">
                    <label class="form-check-label">
                        <input class="form-check-input" type="checkbox"> Remember me
                    </label>
                </div>
                <button type="submit" class="btn btn-warning btn-block mb-3">Submit</button>
                <p>Have not account? <a href="<?php echo e(route('register')); ?>">Create Account</a></p>
            </form>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH D:\laragon\www\OfferYard\resources\views/auth/login.blade.php ENDPATH**/ ?>