<html>
    <head>
        <title>Home | OfferYard</title>
        <?php echo $__env->make('cdn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="bg-light">
        <div class="row m-0">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => []]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.home-slider','data' => []]); ?>
<?php $component->withName('home-slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
        <div class="row m-0">            
            <div class="container">
                <!-- Brands -->
                <h2 class="text-center mt-5">Offers From Stores and Brands You Love</h2>
                <div class="row m-0">
                    <div class="col-md-2"><img src="<?php echo e(asset('images/brands/brand-1.webp')); ?>"></div>
                    <div class="col-md-2"><img src="<?php echo e(asset('images/brands/brand-2.webp')); ?>"></div>
                    <div class="col-md-2"><img src="<?php echo e(asset('images/brands/brand-3.webp')); ?>"></div>
                    <div class="col-md-2"><img src="<?php echo e(asset('images/brands/brand-4.webp')); ?>"></div>
                    <div class="col-md-2"><img src="<?php echo e(asset('images/brands/brand-5.webp')); ?>"></div>
                    <div class="col-md-2"><img src="<?php echo e(asset('images/brands/brand-6.webp')); ?>"></div>
                </div>
                <!-- recent offers -->
                <br/><br/>
                <h1 class="text-center my-5 heading"><u>RECETN OFFERS</u></h1>
                <div class="row m-0">
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/img1@3x.png')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/img2@3x.png')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/img3@3x.png')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/img9@3x.png')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>                    
                </div>
                <!-- end recent offers -->

                <!-- Today offers -->
                <br/><br/>
                <h1 class="text-center my-5 heading"><u>TODAY'S BEST OFFERS</u></h1>
                <div class="row m-0">
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/img1@3x.png')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/img2@3x.png')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/img3@3x.png')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/img9@3x.png')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>                    
                </div>
                <!-- end today's offers -->


                <!-- featured offers -->
                <br/><br/>
                <h1 class=" mt-5 heading"><u>FEATURED OFFERS</u></h1>
                <div class="row m-0">
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/featured-1.webp')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/featured-2.webp')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/featured-3.webp')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 p-1">
                        <div class="row m-0 rounded shadow pb-1">
                            <div class="col-md-12 p-1">
                                <img src="<?php echo e(asset('images/offers/featured-4.webp')); ?>" class="img rounded mt-1" style="width: 100%;">
                                <p class="m-1"><small>From: <b>Rue La La</b></small></p>
                                <p class="m-1 font-weight-bold title">Up to 20% off On-Trend Extras: Belts & More Ft Coach</p>
                                <p class="m-1 text-dark"><small class="mr-2"><s>$69.99</s></small>$49.99</p>
                                <a href="/productdetail" class="btn btn-warning d-block">GET OFFER</a>
                            </div>
                        </div>
                    </div>                    
                </div>
                <!-- end featured offers -->
            </div>
        </div>

        <!-- footer -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footer','data' => []]); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <!-- End Footer -->
    </body>
</html><?php /**PATH D:\laragon\www\OfferYard\resources\views/posts.blade.php ENDPATH**/ ?>